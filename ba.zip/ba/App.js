import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image, ScrollView, StyleSheet, Modal } from 'react-native';
import { MaterialIcons, FontAwesome, FontAwesome5 } from '@expo/vector-icons';

export default function App() {
  const [activeTab, setActiveTab] = useState('Estadia');
  const [activeCategory, setActiveCategory] = useState('Hotéis');
  const [searchVisible, setSearchVisible] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState(null);
  const [selectedSecondFilter, setSelectedSecondFilter] = useState(null);

  const renderImagesForCategory = () => {
    const images = {
      Hotéis: ['https://via.placeholder.com/150', 'https://via.placeholder.com/150', 'https://via.placeholder.com/150'],
      Salões: ['https://via.placeholder.com/150', 'https://via.placeholder.com/150', 'https://via.placeholder.com/150'],
      Residências: ['https://via.placeholder.com/150', 'https://via.placeholder.com/150', 'https://via.placeholder.com/150'],
    };

    return images[activeCategory].map((url, index) => (
      <View key={index} style={styles.card}>
        <Image source={{ uri: url }} style={styles.cardImage} />
        <TouchableOpacity style={styles.favoriteIcon}>
          <FontAwesome name="heart" size={20} color="red" />
        </TouchableOpacity>
        <View style={styles.cardContent}>
          <Text style={styles.cardTitle}>{activeCategory} em Localização Exemplar</Text>
          <Text style={styles.price}>KZ 2.000 por noite</Text>
        </View>
      </View>
    ));
  };

  const toggleSearch = () => {
    setSearchVisible(!searchVisible);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={[styles.headerButton, activeTab === 'Estadia' && styles.activeHeaderButton]}
          onPress={() => setActiveTab('Estadia')}
        >
          <MaterialIcons name="hotel" size={20} color="#fff" />
          <Text style={[styles.tabText, activeTab === 'Estadia' && styles.activeTabText]}>Estadia</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.headerButton, activeTab === 'Carro' && styles.activeHeaderButton]}
          onPress={() => setActiveTab('Carro')}
        >
          <FontAwesome5 name="car" size={20} color="#fff" />
          <Text style={[styles.tabText, activeTab === 'Carro' && styles.activeTabText]}>Aluguer de carro</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.headerButton, activeTab === 'Voos' && styles.activeHeaderButton]}
          onPress={() => setActiveTab('Voos')}
        >
          <MaterialIcons name="flight" size={20} color="#fff" />
          <Text style={[styles.tabText, activeTab === 'Voos' && styles.activeTabText]}>Voos</Text>
        </TouchableOpacity>
      </View>

      {/* Search Section */}
      <TouchableOpacity onPress={toggleSearch} style={styles.searchContainer}>
        <Text style={styles.searchText}>Pesquisa</Text>
        <MaterialIcons name="search" size={20} color="gray" />
      </TouchableOpacity>

      {/* Search Modal */}
      <Modal
        visible={searchVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setSearchVisible(false)}
      >
        <View style={styles.modalContainer}>
          <TouchableOpacity onPress={() => setSearchVisible(false)} style={styles.closeButton}>
            <MaterialIcons name="close" size={24} color="#000" />
          </TouchableOpacity>
          <TextInput placeholder="Digite sua pesquisa" style={styles.searchInput} />
          <TextInput placeholder="Digite sua pesquisa" style={styles.searchInput} />

          <View style={styles.filterButtons}>
            {['Qualquer', 'Quarto', 'Casa inteira'].map((filter, index) => (
              <TouchableOpacity
                key={index}
                style={[styles.filterButton, selectedFilter === filter ? styles.selectedFilterButton : styles.unselectedFilterButton]}
                onPress={() => setSelectedFilter(filter)}
              >
                <Text style={selectedFilter === filter ? styles.selectedFilterText : styles.unselectedFilterText}>{filter}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Imagens abaixo dos botões */}
          <ScrollView style={styles.imageContainer}>
            {renderImagesForCategory()}
          </ScrollView>
        </View>
      </Modal>

      {/* Category Tabs */}
      <View style={styles.categoryContainer}>
        {['Hotéis', 'Salões', 'Residências'].map((category) => (
          <TouchableOpacity
            key={category}
            style={[styles.categoryTab, activeCategory === category && styles.activeCategoryTab]}
            onPress={() => setActiveCategory(category)}
          >
            <Text style={[styles.categoryText, activeCategory === category && styles.activeCategoryText]}>{category}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Card Scroll */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.scrollContainer}>
        {renderImagesForCategory()}
      </ScrollView>

      {/* Footer Navigation */}
      <View style={styles.footer}>
        <TouchableOpacity style={styles.footerTab}>
          <FontAwesome name="home" size={24} color="#6200ee" />
          <Text style={styles.footerText}>Home</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.footerTab}>
          <FontAwesome name="heart" size={24} color="gray" />
          <Text style={styles.footerText}>Favoritos</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.footerTab}>
          <FontAwesome name="book" size={24} color="gray" />
          <Text style={styles.footerText}>Reservas</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.footerTab}>
          <FontAwesome name="user" size={24} color="gray" />
          <Text style={styles.footerText}>Perfil</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#6200ee',
    padding: 15,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  headerButton: {
    alignItems: 'center',
    padding: 10,
    borderRadius: 20,
  },
  activeHeaderButton: {
    backgroundColor: '#4a00b0',
    borderColor: 'white',
    borderWidth: 1,
  },
  tabText: {
    color: '#fff',
    marginTop: 5,
  },
  activeTabText: {
    color: '#fff',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f2f2f2',
    margin: 15,
    padding: 15,
    borderRadius: 8,
    justifyContent: 'space-between',
  },
  searchText: {
    fontSize: 16,
    color: 'gray',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 60,
    paddingHorizontal: 20,
    justifyContent: 'flex-start',
  },
  closeButton: {
    alignSelf: 'flex-end',
    marginBottom: 20,
  },
  searchInput: {
    height: 50,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 10,
    marginBottom: 20,
    width: '100%',
  },
  filterButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 10,
  },
  filterButton: {
    padding: 10,
    borderRadius: 10,
    flex: 1,
    marginHorizontal: 5,
  },
  selectedFilterButton: {
    backgroundColor: 'black',
  },
  unselectedFilterButton: {
    borderColor: '#6200ee',
    borderWidth: 1,
  },
  selectedFilterText: {
    color: 'white',
    textAlign: 'center',
  },
  unselectedFilterText: {
    color: '#6200ee',
    textAlign: 'center',
  },
  imageContainer: {
    marginTop: 20,
    paddingBottom: 20,
    width: '100%',
  },
  categoryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 10,
  },
  categoryTab: {
    paddingVertical: 5,
    paddingHorizontal: 15,
    borderRadius: 20,
  },
  activeCategoryTab: {
    backgroundColor: '#000',
  },
  categoryText: {
    color: 'black',
  },
  activeCategoryText: {
    color: 'white',
  },
  scrollContainer: { paddingVertical: 20, paddingHorizontal: 10 },
  card: { width: '90%', marginBottom: 20, alignSelf: 'center' },
  cardImage: { width: '100%', height: 120, borderRadius: 10 },
  cardContent: { padding: 10 },
  cardTitle: { fontSize: 16, fontWeight: 'bold' },
  price: { fontSize: 14, color: 'green' },
  favoriteIcon: {
    position: 'absolute',
    top: 10,
    right: 10,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: 'red',
    padding: 5,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#fff',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  footerTab: { alignItems: 'center' },
  footerText: { fontSize: 12, color: 'gray', marginTop: 5 },
});
